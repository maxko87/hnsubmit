PowerHN: Keyboard shortcuts for HackerNews (news.ycombinator.com)
Developed by Max Kolysh (maxko87@gmail.com)

List of shortcuts:

Home page:

j, k	: move selector up/down
n, N 	: open link in same/new tab
c, C	: open comments in same/new tab
v, d	: upvote/downvote
##		: select submission ## (e.g. typing 13 selects submission 13)

Comments:

/		: focus on text area
j, k	: move selector up/down
r		: reply
v, d	: upvote/downvote

Reply:

/		: focus on text area